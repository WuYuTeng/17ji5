

public class mainTest {
	public static void main(String[] args) {
		IDUSDemo id=new IDUSDemo();
        //执行添加方法
//		if(id.InsertData(95, "Xiweier", 38389438)){
//			System.out.println("添加失败");
//		}else{
//			System.out.println("添加成功");
//		}
		
		//执行删除方法
		id.deleteData(56);
	}
}

