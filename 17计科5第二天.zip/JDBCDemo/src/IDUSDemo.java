import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;


public class IDUSDemo {
	
	//增加数据的方法
	public boolean InsertData(int id,String name,long num){
		boolean check=false;//自定义变量用来判断到底成功还是不成功
		String sql="insert into student(id,name,num) "
				+ "values("+id+",'"+name+"',"+num+")";
		//1:连接数据库
		Connection conn=ConnectionTest.getCon();
		
		//2:搭建代码与数据库的桥梁使其开始互通
		try {
			Statement sta=conn.createStatement();
		//3:执行SQL语句	
			check=sta.execute(sql);//将数据库操作结果返回给原先设定的中间值
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return check;
	}
	
	//删除数据的方法
	public void deleteData(int id){
		String sql="delete from student where id="+id;
		Connection conn=ConnectionTest.getCon();
	    try {
			Statement sta=conn.createStatement();
			sta.execute(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 	
	}
    
	//查询数据的方法
	public void selectData(int id){
		String sql="select * from student where id="+id;
		Student stu=new Student();
		Connection conn=ConnectionTest.getCon();
	    try {
			Statement sta=conn.createStatement();
			
			ResultSet rs=sta.executeQuery(sql);//执行查询语句并且将其放在ResultSet这个对象当中
			while(rs.next()){//使用循环遍历查询结果,rs.next()方法的意义是每执行一次，集合的下标值就向前一步，一直到超出下标值位置
			  stu.setId(rs.getInt(1));//将数据库查询出来的第一列的类型赋予给stu里面的id	
			  stu.setName(rs.getString(2));
			  stu.setNum(rs.getLong(3));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 	
		
		System.out.println("用户id:"+stu.getId()+"\r\n"
				          +"用户姓名:"+stu.getName()+"\r\n"
				          +"用户学号:"+stu.getNum()); 
	}
	

}

