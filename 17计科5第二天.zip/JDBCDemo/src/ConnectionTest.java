import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;


public class ConnectionTest {
	//静态方法里面是允许存在非静态的外部变量吗？？？-->错误的
	/*
	 JDBC需要学习几个类的使用:
		Connection(连接类)
		Statement(创建代码与数据库桥梁的类)
		ResultSet(存放数据库查询操作结果的类)
    */
	//声明链接数据库所需要的一些参数
	private static String Driver="com.mysql.jdbc.Driver";//驱动类的路径
	private static String name="root";//数据库用户名
	private static String password="123456";//数据库密码
	private static String url="jdbc:mysql://localhost:3838/demo";//数据库的网络地址
	
	//连接数据库的方法
	public static Connection getCon(){
		Connection conn=null;//声明一个数据库连接类
		//加载驱动类
		try {
			Class.forName(Driver);
		/*如果连接成功，数据库将返回一个值给Connection,如果Connection的值为空
		  则表示连接失败，反之则是成功
		*/	
			conn=DriverManager.getConnection(url, name, password);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return conn;
	}
	
	public static void main(String[] args) {
		if(ConnectionTest.getCon()!=null){//静态方法是允许直接使用类名.方法名的方式调用的
			System.out.println("那你很 棒棒哦！！！！");
		}else{
			System.out.println("辣鸡！！！！！");
		}
	}
	
}
